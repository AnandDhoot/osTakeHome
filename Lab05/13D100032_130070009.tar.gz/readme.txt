run make to compile

we assume the exec for get-one-file-sig exists in pwd

we also have set the default serverip and port to 127.0.0.1 5000

it can be changed though using the server command as required

