run make to compile

we assume the exec for get-one-file-sig exists in pwd

we also have harcoded the serverip and port to 127.0.0.1 5000

it can me changed though using the server command

