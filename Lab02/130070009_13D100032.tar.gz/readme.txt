1. Run "make" to make both the executables
2. Run "make clean" to clean up
